-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema meeting_calendar
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema meeting_calendar
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `meeting_calendar` DEFAULT CHARACTER SET utf8 ;
USE `meeting_calendar` ;

-- -----------------------------------------------------
-- Table `meeting_calendar`.`app_users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meeting_calendar`.`app_users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(60) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `meeting_calendar`.`people`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meeting_calendar`.`people` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `app_users_id` INT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE,
  INDEX `fk_people_app_users_idx` (`app_users_id` ASC) VISIBLE,
  CONSTRAINT `fk_people_app_users`
    FOREIGN KEY (`app_users_id`)
    REFERENCES `meeting_calendar`.`app_users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `meeting_calendar`.`meetings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meeting_calendar`.`meetings` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `topic` VARCHAR(45) NOT NULL,
  `meeting_date` DATE NOT NULL,
  `start` TIME NOT NULL,
  `end` TIME NOT NULL,
  `person_org_id` INT NULL,
  `attendant_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_meetings_people1_idx` (`person_org_id` ASC) VISIBLE,
  INDEX `fk_meetings_people2_idx` (`attendant_id` ASC) VISIBLE,
  CONSTRAINT `fk_meetings_people1`
    FOREIGN KEY (`person_org_id`)
    REFERENCES `meeting_calendar`.`people` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_meetings_people2`
    FOREIGN KEY (`attendant_id`)
    REFERENCES `meeting_calendar`.`people` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
